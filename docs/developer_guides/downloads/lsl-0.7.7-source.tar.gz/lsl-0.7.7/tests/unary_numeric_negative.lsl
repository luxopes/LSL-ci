print -[]
