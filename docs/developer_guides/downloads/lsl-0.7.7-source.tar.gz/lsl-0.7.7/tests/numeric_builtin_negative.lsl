print abs({})
