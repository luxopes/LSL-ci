call "immutable".clear()
