print {"a": 1}.get()
