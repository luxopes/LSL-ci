print len(42)
