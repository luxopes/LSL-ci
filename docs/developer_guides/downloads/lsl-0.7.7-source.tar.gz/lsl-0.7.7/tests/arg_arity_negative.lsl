print arg()
