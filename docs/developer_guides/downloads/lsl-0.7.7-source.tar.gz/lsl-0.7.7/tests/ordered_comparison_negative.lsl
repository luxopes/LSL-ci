print "a" < "b"
