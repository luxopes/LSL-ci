print "alpha"
print "beta"
